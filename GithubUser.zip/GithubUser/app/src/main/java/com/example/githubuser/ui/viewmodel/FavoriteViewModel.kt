package com.example.githubuser.ui.viewmodel

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.example.githubuser.data.entity.FavoriteEntity
import com.example.githubuser.data.repository.FavoriteRepository

class FavoriteViewModel (context: Context) : ViewModel() {
    private val favoriteRepository: FavoriteRepository = FavoriteRepository(context)

    fun getFavorite(): LiveData<List<FavoriteEntity>> = favoriteRepository.getFavorite()

    fun delete(favorite: FavoriteEntity) {
        favoriteRepository.delete(favorite)
    }

    fun insertFavorite(favorite: FavoriteEntity) {
        favoriteRepository.insertFavorite(favorite)
    }
}